const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6282340243800'
global.versi = version
global.namaOwner = "Heroikzre"
global.packname = 'Heroikzre Bot'
global.botname = 'Heroikzre Bot'
global.botname2 = 'Heroikzre Design'

global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6282340243800"
global.linkGrup = " "
global.linkchdev = "https://whatsapp.com/channel/0029Vb6H6g4EgGfR7gp00Q01"
global.linkgchero = "https://chat.whatsapp.com/F7yOxYPdJok4qh7dmfdJMz"
global.testiTele = '@refferalairdropID'

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 4000
global.delayPushkontak = 6000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029ValE8PgKAwEirNjqNG3r"
global.idSaluran = "120363303056201004@newsletter"
global.idchdev = "120363418386473821@newsletter"
global.namaSaluran = "Testi By HEROIKZRE"

// Tutorial Ngocok Orkut :
// * Ke CS Orkut @orderkuota 
// Teks :Kak bisa tolong buatin akun H2H kak? 
// Ntar disuruh menuliskan nama dan nomer akun orkut lu
//* klau udh di ksih pencet link okeconnect.com
//* login okeconnect.com
//* klik pojok kanan atas (garis tiga) 
//* klik Payment H2H
//* klik integrasi API
//* jadi deh Api orkut mu
//* yang qris ke website : https://scanqr.org
//Kamu upload gambar qris orderkuota mu 
//Ntar ada semacam nomer/api
//Note :
//Qris orkut wajib kecetak
// Info : https://whatsapp.com/channel/0029VakRR89L7UVPwf53TB0v/2682
global.pinH2H = "-"
global.passwordH2H = "-"
global.merchantIdOrderKuota = "OK2296369"
global.apiOrderKuota = "498351617426016162296369OKCT5F3D5CD0401716106554D58981DA3ACD"
global.qrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214035011014326210303UMI51440014ID.CO.QRIS.WWW0215ID20253801852100303UMI5204541153033605802ID5925HEROIKZRE STORE OK22963696005KUKAR61057525162070703A016304B23A"
global.botToken = '7630038202:AAG1s4A4d46dtqp9bEMKA5gb5tGFWUWQU0Y'


// Settings Api Digital Ocean
global.apiDigitalOcean = "-"

// Settings Api Digital Ocean
global.apiSimpelBot = "simplebotz85"

// Settings harga jualan khusus
global.hargaTele = 700
global.hargaApk = 1500
global.hargaWeb = 1500
global.xaiApiKey = "xai-Y4sO3b94ikRDWPdEfX4PfeoN9SbTulTxzdJGT3Fbz3Fq2lvDRlx5Ui3OJWEg8W4XvbDyWE9yzVU9jRIn"


// Settings All Payment
global.shopepay = "Tidak Tersedia"
global.dana = "081237300464"
global.ovo = "Tidak Tersedia"
global.gopay = "Tidak Tersedia"
global.seabank = "901436426817"
global.ton = "UQBsBKpCO5TrcOgJA25448eU7OwrKU3wmuIv83stS5QgUQnd"
global.etharb = "0xfea01b16b0c933df3ff3cb0dbd625b7501a03446"

// Settings Image Url
global.image = {
menu: "https://img1.pixhost.to/images/5815/599865360_heroikzreofficial.jpg", 
menu2 : "https://img1.pixhost.to/images/5760/598637076_heroikzreofficial.jpg",
allmenu : "https://img1.pixhost.to/images/5760/598637095_heroikzreofficial.jpg",
reply: "https://files.catbox.moe/afhq88.jpg", 
logo: "https://files.catbox.moe/ovx5ap.jpg", 
qris: "https://img1.pixhost.to/images/5815/599892388_heroikzreofficial.jpg",
    qris2 : "https://img1.pixhost.to/images/5760/598639114_heroikzreofficial.jpg",
dana: "https://img102.pixhost.to/images/79/556578147_biyu.jpg", 
ovo: "https://img102.pixhost.to/images/79/556578147_biyu.jpg", 
gopay: "https://img102.pixhost.to/images/79/556578147_biyu.jpg",
spiderman : "https://img1.pixhost.to/images/5483/594797483_biyuofficial.jpg",
antitoxic : "https://img1.pixhost.to/images/5518/595228302_biyuofficial.jpg",
antibot : "https://img1.pixhost.to/images/5714/598044990_heroikzreofficial.jpg",
ton : "https://img1.pixhost.to/images/5600/596321186_biyuofficial.jpg",
sewa : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCPA3uPhXnXrAX6UODcgWqmWeSgrIIaY_L4A&s",
sewamenu :"https://img1.pixhost.to/images/5760/598637111_heroikzreofficial.jpg"
}

// Settings Api Panel Pterodactyl
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://-"
global.apikey = "-" //ptla
global.capikey = "-" //ptlc

// Settings Api Panel Pterodactyl Server 2
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://-"
global.apikeyV2 = "-" //ptla
global.capikeyV2 = "-" //ptlc

// Settings Api Subdomain
global.subdomain = {
"privatehost.us.kg": {
"zone": "790918217c4add75b7684458518c5836", 
"apitoken": "qYv4NvEN6ZcUIv4dEXihjkmQMwbP_-3Qy_zFlAHv"
}, 
"botwhatsapp.us.kg": {
"zone": "fb1ac418c5564373a56c91d962b30dca", 
"apitoken": "rfQih0XNXiq7AyEuDoLjoFfHX2mhYf_9kddAdKIo"
}, 
"skyzopedia.us.kg": {
"zone": "9e4e70b438a65c1d3e6d0e48b82d79de", 
"apitoken": "odilM9DpvLVPodbPyZwW7UcDKg1aIWsivJc0Vt_o"
}, 
"marketplace.us.kg": {
"zone": "2f33118c3db00b12c38d07cf1c823ed1", 
"apitoken": "6WS_Op6yuPOWcO17NiO-sOP8Vq9tjSAFZyAn82db"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "ZPAXx7CL51PtbGweL2pE3BsI3x0hgTgLuy56iXuo"
}, 
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"biyu-offc.biz.id": {
"zone": "486604cbd7c410b1d883ce35da2d95f6", 
"apitoken": "dQ-ngEWnm19tYkh5AwZa2jCmCkE7cXyuCDSuEdMR"
}, 
"biyu.biz.id": {
"zone": "c2fe010b63d4c0d309577fc9bd6f9c1f", 
"apitoken": "2SoTGasHWwiuKAnlDA_4a3_m2aGTmZkumFLPPXu4"
}, 
"devzzhosting.my.id": {
"zone": "f994c2f66ea24d81ea5f4a17a57a725f", 
"apitoken": "AqzTJ13YE2ZxmKXdBP4imLhFMFPjN8VUt9mpbTGq"
}
}

// Message Command 
global.mess = {
	owner: "*[ DITOLAK LAH ]*\nFitur Ini Cuman Buat Heroikzre Bang >.< !",
	admin: "*[ Akses Ditolak ]*\nFitur ini hanya untuk admin grup ya bang XD !!",
	botAdmin: "*[ No ACCESS ]*\n*NO ACCESS Bjir*, Jadiin Dulu lah Admin _- !",
	group: "*[ Akses Ditolak ]*\nFitur ini *cuman bisa dipakai di Grup OI* @.@ !!",
	private: "*[ Akses DITOLAK ]*\nFitur ini *Rahasia*, Jadi Cuman Bisa Dipakai Di Privat Chat Yak :l !",
	prem: "*[ Akses Ditolak ]*\nFitur ini cuman Khusus Owner Dan User Premium HERO >< !",
	wait: "Lagi Proses Ya Bang , Mohon Bersabar ini bukan ujian ;-; . . .", 
	error: 'eh , keknya ada yang error deh..., Hero Coba kasih tau owner yaQ!',
	done: 'Done Lah , Jangan Lupa Bilang Makasih -_ '
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})