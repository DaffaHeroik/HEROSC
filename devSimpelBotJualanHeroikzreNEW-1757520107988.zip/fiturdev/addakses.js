const axios = require('axios')

const repoOwner = 'DaffaHeroik'
const repoName = 'Hero-BOT'
const pathFile = 'whitelist.json'
const githubToken = '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' // Ganti sesuai tokenmu

function jidToNumber(jid) {
  return jid.split('@')[0]
}

async function fetchWhitelist() {
  const res = await axios.get(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${pathFile}`, {
    headers: { Authorization: `token ${githubToken}` }
  })
  const contentBuffer = Buffer.from(res.data.content, 'base64')
  return {
    whitelist: JSON.parse(contentBuffer.toString('utf8')),
    sha: res.data.sha
  }
}

async function updateWhitelist(newWhitelist, sha, message) {
  const newContent = Buffer.from(JSON.stringify(newWhitelist, null, 2)).toString('base64')
  await axios.put(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${pathFile}`, {
    message,
    content: newContent,
    sha
  }, {
    headers: { Authorization: `token ${githubToken}` }
  })
}

async function aksesBotHandler({ conn, m, args, command, isCreator }) {
  if (!isCreator) return await conn.sendMessage(m.chat, { text: 'Hanya owner yang bisa mengakses fitur ini.' })

  const { whitelist, sha } = await fetchWhitelist()

  switch (command) {
    case 'addaksesbot': {
      const nomorBaru = args[0]
      if (!nomorBaru) return await conn.sendMessage(m.chat, { text: 'Masukkan nomor yang ingin ditambahkan.' })
      if (!/^\d{9,15}$/.test(nomorBaru)) {
  return await conn.sendMessage(m.chat, { text: 'Nomor tidak valid. Gunakan format angka saja (tanpa + atau -).' })
}


      const nomorJid = nomorBaru
      if (whitelist.includes(nomorJid)) {
        return await conn.sendMessage(m.chat, { text: `Nomor ${nomorBaru} sudah ada di whitelist.` })
      }

      whitelist.push(nomorJid)
      await updateWhitelist(whitelist, sha, `Add access for ${nomorJid}`)
      await conn.sendMessage(m.chat, { text: `✅ Berhasil menambahkan ${nomorBaru} ke whitelist.` })
      break
    }

    case 'delaksesbot': {
      const nomorTarget = args[0]
      if (!nomorTarget) return await conn.sendMessage(m.chat, { text: 'Masukkan nomor yang ingin dihapus.' })
      if (!/^\d{9,15}$/.test(nomorTarget)) {
  return await conn.sendMessage(m.chat, { text: 'Nomor tidak valid. Gunakan format angka saja (tanpa + atau -).' })
}

if (!whitelist.includes(nomorTarget)) {
  return await conn.sendMessage(m.chat, { text: `Nomor ${nomorTarget} tidak ada dalam whitelist.` })
}

const newWhitelist = whitelist.filter(no => no !== nomorTarget)
await updateWhitelist(newWhitelist, sha, `Remove access for ${nomorTarget}`)

      await conn.sendMessage(m.chat, { text: `✅ Nomor ${nomorTarget} telah dihapus dari whitelist.` })
      break
    }

    case 'listaksesbot': {
      if (whitelist.length === 0) {
        return await conn.sendMessage(m.chat, { text: 'Whitelist kosong.' })
      }

      const nomorList = whitelist.map((jid, i) => `${i + 1}. ${jidToNumber(jid)}`).join('\n')
      await conn.sendMessage(m.chat, { text: `📋 Daftar whitelist:\n${nomorList}` })
      break
    }

    default:
      await conn.sendMessage(m.chat, { text: 'Perintah tidak dikenali.' })
  }
}

module.exports = aksesBotHandler
