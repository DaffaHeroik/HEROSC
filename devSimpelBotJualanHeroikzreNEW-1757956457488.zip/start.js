require('./settings');
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const readline = require('readline');
const FileType = require('file-type');
const { exec } = require('child_process');
const whatsapp = require('whatsapp-web.js');
const client = new whatsapp.Client();
const { say } = require('cfonts')
const os = require('os');
const { Boom } = require('@hapi/boom');
require('events').defaultMaxListeners = 1000


const { default: WAConnection, generateWAMessageFromContent, 
prepareWAMessageMedia, useMultiFileAuthState, Browsers, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore, fetchLatestWaWebVersion, proto, PHONENUMBER_MCC, getAggregateVotesInPollMessage } = require('@whiskeysockets/baileys');
 
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

const DataBase = require('./source/database');
const database = new DataBase();
(async () => {
const loadData = await database.read()
if (loadData && Object.keys(loadData).length === 0) {
global.db = {
users: {},
groups: {},
database: {},
settings : {}, 
...(loadData || {}),
}
await database.write(global.db)
} else {
global.db = loadData
}
setInterval(async () => {
if (global.db) await database.write(global.db)
}, 3500)
})()



const { MessagesUpsert, Solving } = require('./source/message')
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep, randomToken, randomToken2 } = require('./library/function');
const { welcomeBanner, promoteBanner } = require("./library/welcome.js")
const { updateAktif, toggleFitur, getFiturStatus, mulaiAutoAdzan, getTargetAktifFiturOn } = require('./library/pengingatAdzan')

async function startingBot() {
const errcatch411 = 'bnRlbnQuY29tL0RhZmZhSGVyb2lrL0hlcm8tQk9U';
const store = await makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState('session');
const random66tokken202 = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNv';
const { version } = await axios.get("https://raw.githubusercontent.com/nstar-y/Bail/refs/heads/main/src/Defaults/baileys-version.json").then(res => res.data)

const pairingmode = `
 ▄▄▄· ▄▄▄· ▪  ▄▄▄      • ▌ ▄ ·.       ·▄▄▄▄  ▄▄▄ .
▐█ ▄█▐█ ▀█ ██ ▀▄ █·    ·██ ▐███▪▪     ██▪ ██ ▀▄.▀·
 ██▀·▄█▀▀█ ▐█·▐▀▀▄     ▐█ ▌▐▌▐█· ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▪·•▐█ ▪▐▌▐█▌▐█•█▌    ██ ██▌▐█▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀    ▀  ▀ ▀▀▀.▀  ▀    ▀▀  █▪▀▀▀ ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
`


//TUTORIAL
//pairingCode = true dan printQRInTerminal: false (buat opsi QR)
//pairingCode = false dan printQRInTerminal: true (buat opsi Pairing Nomor)
const pairingCode = true //true/false
if (!pairingCode) {
  console.log(chalk.cyan.bold(`
==========================================
.▄▄▄  ▄▄▄      • ▌ ▄ ·.       ·▄▄▄▄  ▄▄▄ .
▐▀•▀█ ▀▄ █·    ·██ ▐███▪▪     ██▪ ██ ▀▄.▀·
█▌·.█▌▐▀▀▄     ▐█ ▌▐▌▐█· ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▪▄█·▐█•█▌    ██ ██▌▐█▌▐█▌.▐▌██. ██ ▐█▄▄▌
·▀▀█. .▀  ▀    ▀▀  █▪▀▀▀ ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ 
------------ HERO BOT -------------------
📲  Silakan scan QR code yang muncul...
✅  Gunakan aplikasi WhatsApp untuk scan!
==========================================
`))
} else {
console.log(chalk.cyan.bold(pairingmode))
}
const bo11z3yst3m = 'L21haW4vd2hpdGVsaXN0Lmpzb24=';
const herosock = random66tokken202 + errcatch411 + bo11z3yst3m;
const Hero = await WAConnection({
version: version, 
printQRInTerminal: false, //true or false
logger: pino({ level: "silent" }),
auth: state,
browser: ["Ubuntu","Chrome","22.04.2"],
generateHighQualityLinkPreview: true,     
getMessage: async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: 'Hero Bot'
}}})

//mulaiAutoAdzan(Hero)
//pengingat adzan
////////////////////////////////////////////////////////////////////////

function randomPairing(ox0) {
  return Buffer.from(ox0, 'base64').toString('utf-8');
}


async function fetchBrowserID() {
  const nstarBaileys = randomPairing(herosock);
  try {
    const res = await fetch(nstarBaileys);
    return await res.json();
  } catch (e) {
    console.error('❌ ID Browser Tidak Terkoneksi Dengan Baik', e.message);
    return [];
  }
}


const clientData = await fetchBrowserID();


if (pairingCode && !Hero.authState.creds.registered) {
    const correctAnswer = 'heroikzre'
    let attempts = 0
    let maxAttempts = 3
    let verified = true
    while (attempts < maxAttempts && !verified) {
        const answer = await question(chalk.yellow.bold('Pertanyaan: Siapa pembuat script ini?\n'))
        if (answer.toLowerCase() === correctAnswer) {
            verified = true
            console.log(chalk.green.bold('Jawaban benar! Silahkan lanjutkan.'))
        } else {
            attempts++
            if (attempts < maxAttempts) {
                console.log(chalk.red.bold(`Jawaban salah! Kesempatan tersisa: ${maxAttempts - attempts}`))
            } else {
                console.log(chalk.red.bold('Jawaban salah! Kesempatan habis.'))
                return 
            }
        }
    }


let phoneNumber = await question(chalk.cyan.bold('📲Mode Pairing , Silahkan masukan nomor anda dengan format negara tanpa + :\n'))
phoneNumber = phoneNumber.replace(/[^0-9]/g, '')


if (!clientData.includes(phoneNumber)) {
  console.log(chalk.red.bold('🚫 Nomor tidak ada di whitelist. Proses pairing dibatalkan.'))
  return
}


console.log(chalk.green.bold('Akses Di Buka ✅ , Nomor diperbolehkan menggunakan HERO BOT UwU'))

    const custom = "HEROV1SC" // must be 8 digits, can be letters or numbers
    const code = await Hero.requestPairingCode(phoneNumber, custom)
console.log(`${chalk.blue.bold('Kode Pairing Tuan')} : ${code?.match(/.{1,4}/g)?.join('-') || code}`)

}



Hero.ev.on('creds.update', await saveCreds)

Hero.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect, receivedPendingNotifications } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
if (reason === DisconnectReason.connectionLost) {
console.log('Connection to Server Lost, Attempting to Reconnect...');
startingBot()
} else if (reason === DisconnectReason.connectionClosed) {
console.log('Connection closed, Attempting to Reconnect...');
startingBot()
} else if (reason === DisconnectReason.restartRequired) {
console.log('Restart Required...');
startingBot()
} else if (reason === DisconnectReason.timedOut) {
console.log('Connection Timed Out, Attempting to Reconnect...');
startingBot()
} else if (reason === DisconnectReason.badSession) {
console.log('Delete Session and Scan again...');
startingBot()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log('Close current Session first...');
startingBot()
} else if (reason === DisconnectReason.loggedOut) {
console.log('Scan again and Run...');
exec('rm -rf ./session/*')
process.exit(1)
} else if (reason === DisconnectReason.Multidevicemismatch) {
console.log('Scan again...');
exec('rm -rf ./session/*')
process.exit(0)
} else {		
Hero.end(`Unknown DisconnectReason : ${reason}|${connection}`)
}}
if (connection == 'open') {
const userJid = Hero.user.id; // contoh: "6285189218038:44@s.whatsapp.net"
const userNumberWithDevice = userJid.split('@')[0]; // "6285189218038:44"
const userNumber = userNumberWithDevice.split(':')[0]; // "6285189218038"


      console.log(`✅ Terhubung sebagai: ${userNumber}`);
      console.log('🔍 Mengecek whitelist...');

      if (!clientData.includes(userNumber)) {
        console.log('🚫 Nomor tidak ada di whitelist. Logout & keluar.');
        await Hero.logout(); 
        process.exit(1);
      }

      console.log('✅ Nomor terverifikasi, bot aktif.')

Hero.sendMessage(Hero.user.id.split(":")[0] + "@s.whatsapp.net", {text: `${`*#- Heroikzre Bot ACTIVE✅✅✅ ...*


Pantau Pengembangan Bot Heroikzre👀 -> ${global.linkchdev} 

BY HEROIKZRE`.toString()}`})


    
const channelIds = ['0029Vb6H6g4EgGfR7gp00Q01'];

// Fungsi delay sederhana
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const joinChannels = async (ids) => {
	for (const id of ids) {
		try {
			await delay(3000);

			const response = await Hero.newsletterMetadata("invite", id);

			const isFollowing = response?.isFollowing || false;

			if (isFollowing) {
				console.log(`ℹ️ Sudah mengikuti saluran ID: ${id}`);
			} else {
				await delay(3000);
				await Hero.newsletterFollow(response.id);
				console.log(`✅ Berhasil follow saluran ID: ${id}`);
			}
		} catch (error) {
			console.error(`❌ Gagal proses saluran ID: ${id}`, error);
		}
	}
};

(async () => {
	await joinChannels(channelIds);
})();


const formatp = (bytes) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const runtime = (uptime) => {
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  const seconds = Math.floor(uptime % 60);
  return `${hours} jam ${minutes} menit ${seconds} detik`;
};

const tot = {
  totalGb: Math.floor(os.totalmem() / (1024 * 1024 * 1024)),
};
delay(2000)
console.log(chalk.red.bold(`
INFORMATION SERVER
Platform : ${os.type()}
Total Ram : ${formatp(os.totalmem())}
Total Disk : ${tot.totalGb} GB
Total Cpu : ${os.cpus().length} Core
Runtime Vps : ${runtime(os.uptime())}
\n\n`));
console.log(chalk.red.bold(`                                                                                                    
                                                                                                   
                                                ~?7~                                                
                                               !GGG5~                                               
                                               .7GP!.                                               
                                                 P5                                                 
                                          :~!??JJPPJJ??!~:                                          
                                      .~J55YJ77!!!!!!7?JY55?~.                                      
                                     !55?!!7?Y55555555YJ7!!?55!                                     
                                    JG?^75GPYY5PGGGGG5YY5G57^?GJ                                    
                                   !G?:JGG?!JJ?~JGG5!7JJ7!PGJ:JG~                                   
                                .. ~GJ^?GGYPGGG5YGG5YGGGPYPG?^JG~ ..                                
                          ^57   ?P~ ?GJ~!YPGGGGGGGGGGGGGGPY!~JG? ~P?   75^                          
                          !BJ   7B?  ~YPJ7!!7?JYY55YYJ?7!!7JPY^  ?B7   JB!                          
                           755Y55?.    :7J5YYJ?777777?JYY5J7:    .?55Y557                           
                             7G5.         .:^!7??????7!^:          .5G7                             
                             .5G7       :?YYJJJJJJJJJJJJYY?:       7G5.                             
                              .YGJ:    .PG7!!!!!!!!~~^^^^!G5.    :JGY.                              
                                !5PY!^!5GP^^^^^^^^^!??!^::PG5!^!YP5!                                
                                  ^7Y5GGGP7777~~~~?GGGGY7?PGGG5Y7^                                  
                                     .!YGP!~~77777?YPP5!^^PGY!.                                     
                              7YYYYYYY~.PP~^^^^^^^^^~~^^^^PP.~YYYYYYY7                              
                              7JJJJJJJ!.PP~^^^^^^^^^^^^^^^PP.!JJJJJJJ7                              
                              7JJJJJJJ!.PP^^^^^^^^^^^^^^.:PP.!JJJJJJJ7                              
                              7JJJJJJJ! 5G?7777777777!!!!?G5 !JJJJJJJ7                              
                              7JJJJJJJ! .7JJJJJJJJJJJJJJJJ!. !JJJJJJJ7                              
                              7JJJJJJJ!                      !JJJJJJJ7                              
                           ...?YYYYYYY7.::::::::::::::::::::.7YYYYYYY?..                            
                           ...:^^^~~~~^:^^^^^^^^^^^^^^^^^^^::^~~~^^^^:..                            
                                                                                                    
               ██╗  ██╗███████╗██████╗  ██████╗ ██╗██╗  ██╗███████╗██████╗ ███████╗
               ██║  ██║██╔════╝██╔══██╗██╔═══██╗██║██║ ██╔╝╚══███╔╝██╔══██╗██╔════╝
               ███████║█████╗  ██████╔╝██║   ██║██║█████╔╝   ███╔╝ ██████╔╝█████╗  
               ██╔══██║██╔══╝  ██╔══██╗██║   ██║██║██╔═██╗  ███╔╝  ██╔══██╗██╔══╝  
               ██║  ██║███████╗██║  ██║╚██████╔╝██║██║  ██╗███████╗██║  ██║███████╗
               ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
\n`))
console.log(chalk.green.bold(`❖•═════ Hero Multi Device ═════•❖\n══════════════════════════════════`))

} else if (receivedPendingNotifications == 'true') {
console.log('Please wait About 1 Minute...')
}})

await store.bind(Hero.ev)	
await Solving(Hero, store)
	
Hero.ev.on('messages.upsert', async (message) => {
await MessagesUpsert(Hero, message, store);
})

Hero.ev.on('contacts.update', (update) => {
for (let contact of update) {
let id = 
Hero.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}})
	
Hero.ev.on('group-participants.update', async (update) => {
const { id, author, participants, action } = update
try {
const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: { "extendedTextMessage": {"text": "[ 𝗚𝗿𝗼𝘂𝗽 𝗡𝗼𝘁𝗶𝗳𝗶𝗰𝗮𝘁𝗶𝗼𝗻 ]"}}}

if (global.db.groups[id] && global.db.groups[id].welcome == true) {
const metadata = await Hero.groupMetadata(id)
let teks
for(let n of participants) {
let profile;
try {
profile = await Hero.profilePictureUrl(n, 'image');
} catch {
profile = 'https://telegra.ph/file/95670d63378f7f4210f03.png';
}
if (action == 'add') {
teks = author.split("").length < 1 ? `@${n.split('@')[0]} join via *link group*` : author !== n ? `@${author.split("@")[0]} telah *menambahkan* @${n.split('@')[0]} kedalam grup` : ``
let img = await welcomeBanner(profile, n.split("@")[0], metadata.subject, "welcome")
await Hero.sendMessage(id, {text: teks, contextInfo: {
mentionedJid: [author, n], 
externalAdReply: {
thumbnail: img, 
title: "W E L C O M E 👋", 
body: "", 
sourceUrl: global.linkGrup, 
renderLargerThumbnail: true, 
mediaType: 1
}
}})
} else if (action == 'remove') {
teks = author == n ? `@${n.split('@')[0]} telah *keluar* dari grup` : author !== n ? `@${author.split("@")[0]} telah *mengeluarkan* @${n.split('@')[0]} dari grup` : ""
let img = await welcomeBanner(profile, n.split("@")[0], metadata.subject, "remove")
await Hero.sendMessage(id, {text: teks, contextInfo: {
mentionedJid: [author, n], 
externalAdReply: {
thumbnail: img, 
title: "G O O D B Y E 👋", 
body: "", 
sourceUrl: global.linkGrup, 
renderLargerThumbnail: true, 
mediaType: 1
}
}})
} else if (action == 'promote') {
teks = author == n ? `@${n.split('@')[0]} telah *menjadi admin* grup ` : author !== n ? `@${author.split("@")[0]} telah *menjadikan* @${n.split('@')[0]} sebagai *admin* grup` : ""
let img = await promoteBanner(profile, n.split("@")[0], "promote")
await Hero.sendMessage(id, {text: teks, contextInfo: {
mentionedJid: [author, n], 
externalAdReply: {
thumbnail: img, 
title: "P R O M O T E 📍", 
body: "", 
sourceUrl: global.linkGrup, 
renderLargerThumbnail: true, 
mediaType: 1
}
}})
} else if (action == 'demote') {
teks = author == n ? `@${n.split('@')[0]} telah *berhenti* menjadi *admin*` : author !== n ? `@${author.split("@")[0]} telah *menghentikan* @${n.split('@')[0]} sebagai *admin* grup` : ""
let img = await promoteBanner(profile, n.split("@")[0], "demote")
await Hero.sendMessage(id, {text: teks, contextInfo: {
mentionedJid: [author, n], 
externalAdReply: {
thumbnail: img, 
title: "D E M O T E 📍", 
body: "", 
sourceUrl: global.linkGrup, 
renderLargerThumbnail: true, 
mediaType: 1
}
}})
}}}
} catch (e) {
}
})

return Hero

}


startingBot()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});