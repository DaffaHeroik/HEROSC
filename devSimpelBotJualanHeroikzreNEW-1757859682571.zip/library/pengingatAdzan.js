const cron = require('node-cron')
const zona = 'Asia/Makassar'
const axios = require('axios')


let fiturAktif = {} // fiturAktif[id] = true/false
let userAktif = {} // userAktif[id] = timestamp



const now = new Date(new Date().getTime() + 120000) // 2 menit ke depan
const jamPlus2 = now.toLocaleTimeString('id-ID', { timeZone: zona, hour12: false }).slice(0, 5).replace('.', ':')

const jadwalSholat = {
  subuh: '04:38',
  dzuhur: '11:56',
  ashar: '15:14',
  maghrib: '17:55',
  isya: '19:05'
}





function toggleFitur(id, status) {
  fiturAktif[id] = status
}

function getFiturStatus(id) {
  return fiturAktif[id] === true
}


function updateAktif(id) {
  userAktif[id] = Date.now()
}


function getTargetAktifFiturOn() {
  return Object.keys(fiturAktif).filter(id => fiturAktif[id] === true)
}



function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}
let cronStarted = false

function mulaiAutoAdzan(conn) {
  if (cronStarted) return
  cronStarted = true
  console.log('Inisialisasi Fitur Pengingat Sholat....')

  cron.schedule('* * * * *', async () => {
    const now = new Date()
      .toLocaleTimeString('id-ID', { timeZone: zona, hour12: false })
      .slice(0, 5)
      .replace('.', ':')

  const target = getTargetAktifFiturOn()

  if (target.length > 0) {
    console.log(`[DEBUG] Cron check waktu sekarang: ${now}`)
    console.log('[DEBUG] Daftar fiturAktif sekarang:', fiturAktif)
  }

    for (const [sholat, waktu] of Object.entries(jadwalSholat)) {
      if (now === waktu) {
        console.log(`[DEBUG] Waktu cocok: ${sholat} (${now})`)

        const target = getTargetAktifFiturOn()
        if (target.length === 0) {
          console.log('[DEBUG] Tidak ada chat yang mengaktifkan fitur adzan.')
          return
        }

        const teks = `🕌 Waktunya adzan *${sholat.toUpperCase()}* untuk wilayah *Makassar*.\nJangan lupa sholat ya!`
        const audioUrl = 'https://files.catbox.moe/6ssrmg.mp3'
        const imgMasjid = 'https://img1.pixhost.to/images/4978/587223973_biyuofficial.jpg'

        const res = await axios.get(audioUrl, { responseType: 'arraybuffer' })
        const audioBuffer = Buffer.from(res.data)

        for (const [index, id] of target.entries()) {
          try {
            console.log(`Mempersiapkan kirim pesan ke ${id}`)
            await delay(index * 5000)

            await conn.sendMessage(id, {
              text: teks,
              mentions: [id],
              contextInfo: {
                externalAdReply: {
                  thumbnailUrl: imgMasjid,
                  title: `🛑 ${sholat.toUpperCase()} telah tiba!`
                }
              }
            }, { quoted: null })

            await delay(1000)
            await conn.sendMessage(id, {
              audio: audioBuffer,
              mimetype: 'audio/mp4',
              ptt: false
            })

            console.log(`Pengingat adzan ${sholat} dikirim ke ${id}`)
          } catch (err) {
            console.error(`Gagal kirim ke ${id}:`, err.message)
          }
        }
      }
    }
  })
}



module.exports = { updateAktif, toggleFitur, getFiturStatus, mulaiAutoAdzan }