// utils/tambahWhitelist.js
const axios = require('axios')

const repoOwner = 'DaffaHeroik'
const repoName = 'Hero-BOT'
const pathFile = 'whitelist.json'
const githubToken = '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' // Ganti tokenmu

async function tambahWhitelistOtomatis(sender) {
  const nomor = sender.split('@')[0]

  try {
    const res = await axios.get(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${pathFile}`, {
      headers: { Authorization: `token ${githubToken}` }
    })

    const whitelist = JSON.parse(Buffer.from(res.data.content, 'base64').toString('utf8'))
    const sha = res.data.sha

    if (whitelist.includes(nomor)) return console.log('Pembelian baru dan sudah terdaftar') // Sudah terdaftar

    whitelist.push(nomor)

    await axios.put(`https://api.github.com/repos/${repoOwner}/${repoName}/contents/${pathFile}`, {
      message: `Auto add access for ${nomor}`,
      content: Buffer.from(JSON.stringify(whitelist, null, 2)).toString('base64'),
      sha
    }, {
      headers: { Authorization: `token ${githubToken}` }
    })

    console.log(`✅ ${nomor} ditambahkan ke whitelist.`)
  } catch (err) {
    console.error('❌ Gagal update whitelist:', err.message)
  }
}

module.exports = tambahWhitelistOtomatis
